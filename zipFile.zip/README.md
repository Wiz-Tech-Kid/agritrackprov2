
  # Livestock Tracking Dashboard

  This is a code bundle for Livestock Tracking Dashboard. The original project is available at https://www.figma.com/design/FXZakxGYreq3GvncWfb1rd/Livestock-Tracking-Dashboard.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  