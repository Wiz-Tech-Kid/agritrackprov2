import { useEffect, useState } from 'react';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { Label } from './ui/label';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogTrigger } from './ui/dialog';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from './ui/select';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from './ui/table';
import { Badge } from './ui/badge';
import { Beef, Plus, Edit, Trash2, Search, MapPin } from 'lucide-react';
import { projectId, publicAnonKey } from '../utils/supabase/info';
import { toast } from 'sonner';
import { SampleDataLoader } from './SampleDataLoader';
import { GoogleSheetsSync } from './GoogleSheetsSync';

interface LivestockManagementProps {
  accessToken: string;
}

interface Animal {
  id: string;
  rfidTag: string;
  breed: string;
  age: number;
  healthStatus: string;
  weight?: number;
  gender?: string;
  location?: {
    lat: number;
    lng: number;
    name?: string;
  };
  lastSeen?: string;
  createdAt: string;
}

export function LivestockManagement({ accessToken }: LivestockManagementProps) {
  const [livestock, setLivestock] = useState<Animal[]>([]);
  const [filteredLivestock, setFilteredLivestock] = useState<Animal[]>([]);
  const [loading, setLoading] = useState(true);
  const [searchTerm, setSearchTerm] = useState('');
  const [isAddDialogOpen, setIsAddDialogOpen] = useState(false);
  const [isEditDialogOpen, setIsEditDialogOpen] = useState(false);
  const [editingAnimal, setEditingAnimal] = useState<Animal | null>(null);

  // Form state
  const [formData, setFormData] = useState({
    rfidTag: '',
    breed: '',
    age: '',
    healthStatus: 'healthy',
    weight: '',
    gender: 'female',
    locationName: ''
  });

  useEffect(() => {
    fetchLivestock();
  }, []);

  useEffect(() => {
    // Filter livestock based on search
    if (searchTerm) {
      const filtered = livestock.filter(animal =>
        animal.rfidTag.toLowerCase().includes(searchTerm.toLowerCase()) ||
        animal.breed.toLowerCase().includes(searchTerm.toLowerCase()) ||
        animal.id.toLowerCase().includes(searchTerm.toLowerCase())
      );
      setFilteredLivestock(filtered);
    } else {
      setFilteredLivestock(livestock);
    }
  }, [searchTerm, livestock]);

  const fetchLivestock = async () => {
    try {
      const response = await fetch(
        `https://${projectId}.supabase.co/functions/v1/make-server-ebf166d3/livestock`,
        {
          headers: { 'Authorization': `Bearer ${accessToken}` }
        }
      );

      const data = await response.json();
      if (!response.ok) {
        console.error('Error fetching livestock:', data.error);
        toast.error('Failed to fetch livestock');
      } else {
        setLivestock(data.livestock || []);
        setFilteredLivestock(data.livestock || []);
      }
      setLoading(false);
    } catch (error) {
      console.error('Error fetching livestock:', error);
      toast.error('Failed to fetch livestock');
      setLoading(false);
    }
  };

  const handleAddAnimal = async (e: React.FormEvent) => {
    e.preventDefault();

    try {
      const response = await fetch(
        `https://${projectId}.supabase.co/functions/v1/make-server-ebf166d3/livestock`,
        {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
            'Authorization': `Bearer ${accessToken}`
          },
          body: JSON.stringify({
            rfidTag: formData.rfidTag,
            breed: formData.breed,
            age: parseInt(formData.age),
            healthStatus: formData.healthStatus,
            weight: formData.weight ? parseFloat(formData.weight) : undefined,
            gender: formData.gender,
            location: formData.locationName ? {
              name: formData.locationName,
              lat: 0, // In real implementation, this would come from GPS
              lng: 0
            } : undefined,
            lastSeen: new Date().toISOString()
          })
        }
      );

      const result = await response.json();
      if (!response.ok) {
        console.error('Error adding livestock:', result.error);
        toast.error(result.error || 'Failed to add livestock');
      } else {
        toast.success('Livestock added successfully');
        setIsAddDialogOpen(false);
        resetForm();
        fetchLivestock();
      }
    } catch (error) {
      console.error('Error adding livestock:', error);
      toast.error('Failed to add livestock');
    }
  };

  const handleEditAnimal = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!editingAnimal) return;

    try {
      const response = await fetch(
        `https://${projectId}.supabase.co/functions/v1/make-server-ebf166d3/livestock/${editingAnimal.id}`,
        {
          method: 'PUT',
          headers: {
            'Content-Type': 'application/json',
            'Authorization': `Bearer ${accessToken}`
          },
          body: JSON.stringify({
            rfidTag: formData.rfidTag,
            breed: formData.breed,
            age: parseInt(formData.age),
            healthStatus: formData.healthStatus,
            weight: formData.weight ? parseFloat(formData.weight) : undefined,
            gender: formData.gender,
            location: formData.locationName ? {
              name: formData.locationName,
              lat: editingAnimal.location?.lat || 0,
              lng: editingAnimal.location?.lng || 0
            } : editingAnimal.location
          })
        }
      );

      const result = await response.json();
      if (!response.ok) {
        console.error('Error updating livestock:', result.error);
        toast.error(result.error || 'Failed to update livestock');
      } else {
        toast.success('Livestock updated successfully');
        setIsEditDialogOpen(false);
        setEditingAnimal(null);
        resetForm();
        fetchLivestock();
      }
    } catch (error) {
      console.error('Error updating livestock:', error);
      toast.error('Failed to update livestock');
    }
  };

  const handleDeleteAnimal = async (animalId: string) => {
    if (!confirm('Are you sure you want to delete this animal?')) return;

    try {
      const response = await fetch(
        `https://${projectId}.supabase.co/functions/v1/make-server-ebf166d3/livestock/${animalId}`,
        {
          method: 'DELETE',
          headers: { 'Authorization': `Bearer ${accessToken}` }
        }
      );

      const result = await response.json();
      if (!response.ok) {
        console.error('Error deleting livestock:', result.error);
        toast.error(result.error || 'Failed to delete livestock');
      } else {
        toast.success('Livestock deleted successfully');
        fetchLivestock();
      }
    } catch (error) {
      console.error('Error deleting livestock:', error);
      toast.error('Failed to delete livestock');
    }
  };

  const openEditDialog = (animal: Animal) => {
    setEditingAnimal(animal);
    setFormData({
      rfidTag: animal.rfidTag,
      breed: animal.breed,
      age: animal.age.toString(),
      healthStatus: animal.healthStatus,
      weight: animal.weight?.toString() || '',
      gender: animal.gender || 'female',
      locationName: animal.location?.name || ''
    });
    setIsEditDialogOpen(true);
  };

  const resetForm = () => {
    setFormData({
      rfidTag: '',
      breed: '',
      age: '',
      healthStatus: 'healthy',
      weight: '',
      gender: 'female',
      locationName: ''
    });
  };

  const getHealthBadge = (status: string) => {
    const variants: Record<string, 'default' | 'destructive' | 'outline' | 'secondary'> = {
      healthy: 'default',
      sick: 'destructive',
      treatment: 'secondary'
    };
    return (
      <Badge variant={variants[status] || 'outline'}>
        {status}
      </Badge>
    );
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-3xl mb-2">Livestock Management</h2>
          <p className="text-muted-foreground">
            Register and manage your livestock with RFID tracking
          </p>
        </div>
        <Dialog open={isAddDialogOpen} onOpenChange={setIsAddDialogOpen}>
          <DialogTrigger asChild>
            <Button>
              <Plus className="size-4 mr-2" />
              Add Livestock
            </Button>
          </DialogTrigger>
          <DialogContent className="max-w-md">
            <DialogHeader>
              <DialogTitle>Register New Livestock</DialogTitle>
              <DialogDescription>
                Add a new animal with RFID tag information
              </DialogDescription>
            </DialogHeader>
            <form onSubmit={handleAddAnimal} className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="rfidTag">RFID Tag *</Label>
                <Input
                  id="rfidTag"
                  placeholder="e.g., RFID-001234"
                  value={formData.rfidTag}
                  onChange={(e) => setFormData({ ...formData, rfidTag: e.target.value })}
                  required
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="breed">Breed *</Label>
                <Input
                  id="breed"
                  placeholder="e.g., Holstein"
                  value={formData.breed}
                  onChange={(e) => setFormData({ ...formData, breed: e.target.value })}
                  required
                />
              </div>
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="age">Age (months) *</Label>
                  <Input
                    id="age"
                    type="number"
                    min="0"
                    value={formData.age}
                    onChange={(e) => setFormData({ ...formData, age: e.target.value })}
                    required
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="weight">Weight (kg)</Label>
                  <Input
                    id="weight"
                    type="number"
                    min="0"
                    step="0.1"
                    value={formData.weight}
                    onChange={(e) => setFormData({ ...formData, weight: e.target.value })}
                  />
                </div>
              </div>
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="gender">Gender</Label>
                  <Select value={formData.gender} onValueChange={(v) => setFormData({ ...formData, gender: v })}>
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="female">Female</SelectItem>
                      <SelectItem value="male">Male</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div className="space-y-2">
                  <Label htmlFor="healthStatus">Health Status</Label>
                  <Select value={formData.healthStatus} onValueChange={(v) => setFormData({ ...formData, healthStatus: v })}>
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="healthy">Healthy</SelectItem>
                      <SelectItem value="sick">Sick</SelectItem>
                      <SelectItem value="treatment">Under Treatment</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>
              <div className="space-y-2">
                <Label htmlFor="locationName">Location</Label>
                <Input
                  id="locationName"
                  placeholder="e.g., North Pasture"
                  value={formData.locationName}
                  onChange={(e) => setFormData({ ...formData, locationName: e.target.value })}
                />
              </div>
              <div className="flex gap-2">
                <Button type="button" variant="outline" onClick={() => setIsAddDialogOpen(false)} className="flex-1">
                  Cancel
                </Button>
                <Button type="submit" className="flex-1">Add Animal</Button>
              </div>
            </form>
          </DialogContent>
        </Dialog>
      </div>

      {/* Search */}
      <Card>
        <CardContent className="pt-6">
          <div className="relative">
            <Search className="absolute left-3 top-3 size-4 text-muted-foreground" />
            <Input
              placeholder="Search by RFID tag, breed, or ID..."
              className="pl-10"
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
            />
          </div>
        </CardContent>
      </Card>

      {/* Sample Data Loader - Show only if no livestock */}
      {!loading && livestock.length === 0 && (
        <SampleDataLoader accessToken={accessToken} onDataLoaded={fetchLivestock} />
      )}

      {/* Livestock Table */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Beef className="size-5" />
            Registered Livestock ({filteredLivestock.length})
          </CardTitle>
        </CardHeader>
        <CardContent>
          {loading ? (
            <div className="text-center py-8 text-muted-foreground">
              Loading livestock...
            </div>
          ) : filteredLivestock.length === 0 ? (
            <div className="text-center py-8 text-muted-foreground">
              No livestock found. Add your first animal to get started.
            </div>
          ) : (
            <div className="overflow-x-auto">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>RFID Tag</TableHead>
                    <TableHead>Breed</TableHead>
                    <TableHead>Age</TableHead>
                    <TableHead>Gender</TableHead>
                    <TableHead>Weight</TableHead>
                    <TableHead>Health</TableHead>
                    <TableHead>Location</TableHead>
                    <TableHead>Last Seen</TableHead>
                    <TableHead className="text-right">Actions</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {filteredLivestock.map((animal) => (
                    <TableRow key={animal.id}>
                      <TableCell className="font-mono">{animal.rfidTag}</TableCell>
                      <TableCell>{animal.breed}</TableCell>
                      <TableCell>{animal.age} mo</TableCell>
                      <TableCell className="capitalize">{animal.gender || 'N/A'}</TableCell>
                      <TableCell>{animal.weight ? `${animal.weight} kg` : 'N/A'}</TableCell>
                      <TableCell>{getHealthBadge(animal.healthStatus)}</TableCell>
                      <TableCell>
                        {animal.location?.name ? (
                          <div className="flex items-center gap-1">
                            <MapPin className="size-3" />
                            {animal.location.name}
                          </div>
                        ) : (
                          'N/A'
                        )}
                      </TableCell>
                      <TableCell className="text-sm text-muted-foreground">
                        {animal.lastSeen ? new Date(animal.lastSeen).toLocaleDateString() : 'N/A'}
                      </TableCell>
                      <TableCell className="text-right">
                        <div className="flex justify-end gap-2">
                          <Button
                            variant="ghost"
                            size="sm"
                            onClick={() => openEditDialog(animal)}
                          >
                            <Edit className="size-4" />
                          </Button>
                          <Button
                            variant="ghost"
                            size="sm"
                            onClick={() => handleDeleteAnimal(animal.id)}
                          >
                            <Trash2 className="size-4 text-destructive" />
                          </Button>
                        </div>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </div>
          )}
        </CardContent>
      </Card>

      {/* Edit Dialog */}
      <Dialog open={isEditDialogOpen} onOpenChange={setIsEditDialogOpen}>
        <DialogContent className="max-w-md">
          <DialogHeader>
            <DialogTitle>Edit Livestock</DialogTitle>
            <DialogDescription>
              Update animal information
            </DialogDescription>
          </DialogHeader>
          <form onSubmit={handleEditAnimal} className="space-y-4">
            <div className="space-y-2">
              <Label htmlFor="edit-rfidTag">RFID Tag *</Label>
              <Input
                id="edit-rfidTag"
                value={formData.rfidTag}
                onChange={(e) => setFormData({ ...formData, rfidTag: e.target.value })}
                required
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="edit-breed">Breed *</Label>
              <Input
                id="edit-breed"
                value={formData.breed}
                onChange={(e) => setFormData({ ...formData, breed: e.target.value })}
                required
              />
            </div>
            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="edit-age">Age (months) *</Label>
                <Input
                  id="edit-age"
                  type="number"
                  min="0"
                  value={formData.age}
                  onChange={(e) => setFormData({ ...formData, age: e.target.value })}
                  required
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="edit-weight">Weight (kg)</Label>
                <Input
                  id="edit-weight"
                  type="number"
                  min="0"
                  step="0.1"
                  value={formData.weight}
                  onChange={(e) => setFormData({ ...formData, weight: e.target.value })}
                />
              </div>
            </div>
            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="edit-gender">Gender</Label>
                <Select value={formData.gender} onValueChange={(v) => setFormData({ ...formData, gender: v })}>
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="female">Female</SelectItem>
                    <SelectItem value="male">Male</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div className="space-y-2">
                <Label htmlFor="edit-healthStatus">Health Status</Label>
                <Select value={formData.healthStatus} onValueChange={(v) => setFormData({ ...formData, healthStatus: v })}>
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="healthy">Healthy</SelectItem>
                    <SelectItem value="sick">Sick</SelectItem>
                    <SelectItem value="treatment">Under Treatment</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>
            <div className="space-y-2">
              <Label htmlFor="edit-locationName">Location</Label>
              <Input
                id="edit-locationName"
                value={formData.locationName}
                onChange={(e) => setFormData({ ...formData, locationName: e.target.value })}
              />
            </div>
            <div className="flex gap-2">
              <Button type="button" variant="outline" onClick={() => setIsEditDialogOpen(false)} className="flex-1">
                Cancel
              </Button>
              <Button type="submit" className="flex-1">Update Animal</Button>
            </div>
          </form>
        </DialogContent>
      </Dialog>

      {/* Google Sheets Sync */}
      <GoogleSheetsSync accessToken={accessToken} />
    </div>
  );
}