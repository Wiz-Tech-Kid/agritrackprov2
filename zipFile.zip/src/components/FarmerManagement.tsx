import { useEffect, useState } from 'react';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { Label } from './ui/label';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from './ui/dialog';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from './ui/table';
import { Badge } from './ui/badge';
import { Users, Edit, Trash2, Search, Mail, MapPin } from 'lucide-react';
import { projectId } from '../utils/supabase/info';
import { toast } from 'sonner';

interface FarmerManagementProps {
  accessToken: string;
}

interface Farmer {
  id: string;
  email: string;
  name: string;
  role: string;
  farmLocation?: string;
  createdAt: string;
}

export function FarmerManagement({ accessToken }: FarmerManagementProps) {
  const [farmers, setFarmers] = useState<Farmer[]>([]);
  const [filteredFarmers, setFilteredFarmers] = useState<Farmer[]>([]);
  const [loading, setLoading] = useState(true);
  const [searchTerm, setSearchTerm] = useState('');
  const [isEditDialogOpen, setIsEditDialogOpen] = useState(false);
  const [editingFarmer, setEditingFarmer] = useState<Farmer | null>(null);

  const [formData, setFormData] = useState({
    name: '',
    farmLocation: ''
  });

  useEffect(() => {
    fetchFarmers();
  }, []);

  useEffect(() => {
    if (searchTerm) {
      const filtered = farmers.filter(farmer =>
        farmer.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
        farmer.email.toLowerCase().includes(searchTerm.toLowerCase()) ||
        farmer.farmLocation?.toLowerCase().includes(searchTerm.toLowerCase())
      );
      setFilteredFarmers(filtered);
    } else {
      setFilteredFarmers(farmers);
    }
  }, [searchTerm, farmers]);

  const fetchFarmers = async () => {
    try {
      const response = await fetch(
        `https://${projectId}.supabase.co/functions/v1/make-server-ebf166d3/farmers`,
        {
          headers: { 'Authorization': `Bearer ${accessToken}` }
        }
      );

      const data = await response.json();
      if (!response.ok) {
        console.error('Error fetching farmers:', data.error);
        if (response.status === 403) {
          toast.error('Admin access required');
        } else {
          toast.error('Failed to fetch farmers');
        }
      } else {
        setFarmers(data.farmers || []);
        setFilteredFarmers(data.farmers || []);
      }
      setLoading(false);
    } catch (error) {
      console.error('Error fetching farmers:', error);
      toast.error('Failed to fetch farmers');
      setLoading(false);
    }
  };

  const handleEditFarmer = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!editingFarmer) return;

    try {
      const response = await fetch(
        `https://${projectId}.supabase.co/functions/v1/make-server-ebf166d3/farmers/${editingFarmer.id}`,
        {
          method: 'PUT',
          headers: {
            'Content-Type': 'application/json',
            'Authorization': `Bearer ${accessToken}`
          },
          body: JSON.stringify({
            name: formData.name,
            farmLocation: formData.farmLocation
          })
        }
      );

      const result = await response.json();
      if (!response.ok) {
        console.error('Error updating farmer:', result.error);
        toast.error(result.error || 'Failed to update farmer');
      } else {
        toast.success('Farmer updated successfully');
        setIsEditDialogOpen(false);
        setEditingFarmer(null);
        resetForm();
        fetchFarmers();
      }
    } catch (error) {
      console.error('Error updating farmer:', error);
      toast.error('Failed to update farmer');
    }
  };

  const handleDeleteFarmer = async (farmerId: string) => {
    if (!confirm('Are you sure you want to delete this farmer? This action cannot be undone.')) {
      return;
    }

    try {
      const response = await fetch(
        `https://${projectId}.supabase.co/functions/v1/make-server-ebf166d3/farmers/${farmerId}`,
        {
          method: 'DELETE',
          headers: { 'Authorization': `Bearer ${accessToken}` }
        }
      );

      const result = await response.json();
      if (!response.ok) {
        console.error('Error deleting farmer:', result.error);
        toast.error(result.error || 'Failed to delete farmer');
      } else {
        toast.success('Farmer deleted successfully');
        fetchFarmers();
      }
    } catch (error) {
      console.error('Error deleting farmer:', error);
      toast.error('Failed to delete farmer');
    }
  };

  const openEditDialog = (farmer: Farmer) => {
    setEditingFarmer(farmer);
    setFormData({
      name: farmer.name,
      farmLocation: farmer.farmLocation || ''
    });
    setIsEditDialogOpen(true);
  };

  const resetForm = () => {
    setFormData({
      name: '',
      farmLocation: ''
    });
  };

  return (
    <div className="space-y-6">
      <div>
        <h2 className="text-3xl mb-2">Farmer Management</h2>
        <p className="text-muted-foreground">
          Manage farmer accounts and permissions (Admin Only)
        </p>
      </div>

      {/* Stats */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm">Total Farmers</CardTitle>
            <Users className="size-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl">{farmers.length}</div>
            <p className="text-xs text-muted-foreground">
              Registered accounts
            </p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm">Active This Month</CardTitle>
            <Users className="size-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl">
              {farmers.filter(f => {
                const monthAgo = new Date();
                monthAgo.setMonth(monthAgo.getMonth() - 1);
                return new Date(f.createdAt) > monthAgo;
              }).length}
            </div>
            <p className="text-xs text-muted-foreground">
              Recent signups
            </p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm">Locations</CardTitle>
            <MapPin className="size-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl">
              {new Set(farmers.map(f => f.farmLocation).filter(Boolean)).size}
            </div>
            <p className="text-xs text-muted-foreground">
              Unique farm locations
            </p>
          </CardContent>
        </Card>
      </div>

      {/* Search */}
      <Card>
        <CardContent className="pt-6">
          <div className="relative">
            <Search className="absolute left-3 top-3 size-4 text-muted-foreground" />
            <Input
              placeholder="Search by name, email, or location..."
              className="pl-10"
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
            />
          </div>
        </CardContent>
      </Card>

      {/* Farmers Table */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Users className="size-5" />
            Registered Farmers ({filteredFarmers.length})
          </CardTitle>
        </CardHeader>
        <CardContent>
          {loading ? (
            <div className="text-center py-8 text-muted-foreground">
              Loading farmers...
            </div>
          ) : filteredFarmers.length === 0 ? (
            <div className="text-center py-8 text-muted-foreground">
              No farmers found
            </div>
          ) : (
            <div className="overflow-x-auto">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Name</TableHead>
                    <TableHead>Email</TableHead>
                    <TableHead>Farm Location</TableHead>
                    <TableHead>Role</TableHead>
                    <TableHead>Joined</TableHead>
                    <TableHead className="text-right">Actions</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {filteredFarmers.map((farmer) => (
                    <TableRow key={farmer.id}>
                      <TableCell className="font-medium">{farmer.name}</TableCell>
                      <TableCell>
                        <div className="flex items-center gap-2">
                          <Mail className="size-3 text-muted-foreground" />
                          {farmer.email}
                        </div>
                      </TableCell>
                      <TableCell>
                        {farmer.farmLocation ? (
                          <div className="flex items-center gap-1">
                            <MapPin className="size-3 text-muted-foreground" />
                            {farmer.farmLocation}
                          </div>
                        ) : (
                          <span className="text-muted-foreground">Not set</span>
                        )}
                      </TableCell>
                      <TableCell>
                        <Badge variant="outline" className="capitalize">
                          {farmer.role}
                        </Badge>
                      </TableCell>
                      <TableCell className="text-sm text-muted-foreground">
                        {new Date(farmer.createdAt).toLocaleDateString()}
                      </TableCell>
                      <TableCell className="text-right">
                        <div className="flex justify-end gap-2">
                          <Button
                            variant="ghost"
                            size="sm"
                            onClick={() => openEditDialog(farmer)}
                          >
                            <Edit className="size-4" />
                          </Button>
                          <Button
                            variant="ghost"
                            size="sm"
                            onClick={() => handleDeleteFarmer(farmer.id)}
                          >
                            <Trash2 className="size-4 text-destructive" />
                          </Button>
                        </div>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </div>
          )}
        </CardContent>
      </Card>

      {/* Edit Dialog */}
      <Dialog open={isEditDialogOpen} onOpenChange={setIsEditDialogOpen}>
        <DialogContent className="max-w-md">
          <DialogHeader>
            <DialogTitle>Edit Farmer</DialogTitle>
            <DialogDescription>
              Update farmer information
            </DialogDescription>
          </DialogHeader>
          <form onSubmit={handleEditFarmer} className="space-y-4">
            <div className="space-y-2">
              <Label htmlFor="edit-name">Name</Label>
              <Input
                id="edit-name"
                value={formData.name}
                onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                required
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="edit-farmLocation">Farm Location</Label>
              <Input
                id="edit-farmLocation"
                placeholder="e.g., Green Valley Farm, TX"
                value={formData.farmLocation}
                onChange={(e) => setFormData({ ...formData, farmLocation: e.target.value })}
              />
            </div>
            <div className="flex gap-2">
              <Button
                type="button"
                variant="outline"
                onClick={() => {
                  setIsEditDialogOpen(false);
                  setEditingFarmer(null);
                  resetForm();
                }}
                className="flex-1"
              >
                Cancel
              </Button>
              <Button type="submit" className="flex-1">
                Update Farmer
              </Button>
            </div>
          </form>
        </DialogContent>
      </Dialog>
    </div>
  );
}
