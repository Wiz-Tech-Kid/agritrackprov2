import { useEffect, useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Button } from './ui/button';
import { Badge } from './ui/badge';
import { MapPin, Navigation, RefreshCw, History } from 'lucide-react';
import { projectId } from '../utils/supabase/info';
import { toast } from 'sonner';

interface MapTrackingProps {
  accessToken: string;
}

interface Animal {
  id: string;
  rfidTag: string;
  breed: string;
  healthStatus: string;
  location?: {
    lat: number;
    lng: number;
    name?: string;
  };
  lastSeen?: string;
}

interface Movement {
  id: string;
  animalId: string;
  latitude: number;
  longitude: number;
  timestamp: string;
}

export function MapTracking({ accessToken }: MapTrackingProps) {
  const [livestock, setLivestock] = useState<Animal[]>([]);
  const [selectedAnimal, setSelectedAnimal] = useState<Animal | null>(null);
  const [movements, setMovements] = useState<Movement[]>([]);
  const [loading, setLoading] = useState(true);
  const [loadingMovements, setLoadingMovements] = useState(false);

  useEffect(() => {
    fetchLivestock();
  }, []);

  useEffect(() => {
    if (selectedAnimal) {
      fetchMovementHistory(selectedAnimal.id);
    }
  }, [selectedAnimal]);

  const fetchLivestock = async () => {
    try {
      const response = await fetch(
        `https://${projectId}.supabase.co/functions/v1/make-server-ebf166d3/livestock`,
        {
          headers: { 'Authorization': `Bearer ${accessToken}` }
        }
      );

      const data = await response.json();
      if (!response.ok) {
        console.error('Error fetching livestock:', data.error);
      } else {
        const animalsWithLocation = (data.livestock || []).filter(
          (animal: Animal) => animal.location
        );
        setLivestock(animalsWithLocation);
        if (animalsWithLocation.length > 0 && !selectedAnimal) {
          setSelectedAnimal(animalsWithLocation[0]);
        }
      }
      setLoading(false);
    } catch (error) {
      console.error('Error fetching livestock:', error);
      setLoading(false);
    }
  };

  const fetchMovementHistory = async (animalId: string) => {
    setLoadingMovements(true);
    try {
      const response = await fetch(
        `https://${projectId}.supabase.co/functions/v1/make-server-ebf166d3/movements/${animalId}`,
        {
          headers: { 'Authorization': `Bearer ${accessToken}` }
        }
      );

      const data = await response.json();
      if (!response.ok) {
        console.error('Error fetching movements:', data.error);
      } else {
        setMovements(data.movements || []);
      }
      setLoadingMovements(false);
    } catch (error) {
      console.error('Error fetching movements:', error);
      setLoadingMovements(false);
    }
  };

  const simulateGPSUpdate = async () => {
    if (!selectedAnimal) return;

    // Simulate a random GPS coordinate near the current location
    const currentLat = selectedAnimal.location?.lat || 0;
    const currentLng = selectedAnimal.location?.lng || 0;
    const newLat = currentLat + (Math.random() - 0.5) * 0.01;
    const newLng = currentLng + (Math.random() - 0.5) * 0.01;

    try {
      // Add movement data
      await fetch(
        `https://${projectId}.supabase.co/functions/v1/make-server-ebf166d3/movements`,
        {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
            'Authorization': `Bearer ${accessToken}`
          },
          body: JSON.stringify({
            animalId: selectedAnimal.id,
            latitude: newLat,
            longitude: newLng
          })
        }
      );

      // Update livestock location
      await fetch(
        `https://${projectId}.supabase.co/functions/v1/make-server-ebf166d3/livestock/${selectedAnimal.id}`,
        {
          method: 'PUT',
          headers: {
            'Content-Type': 'application/json',
            'Authorization': `Bearer ${accessToken}`
          },
          body: JSON.stringify({
            ...selectedAnimal,
            location: {
              ...selectedAnimal.location,
              lat: newLat,
              lng: newLng
            },
            lastSeen: new Date().toISOString()
          })
        }
      );

      toast.success('GPS location updated');
      fetchLivestock();
      fetchMovementHistory(selectedAnimal.id);
    } catch (error) {
      console.error('Error updating GPS:', error);
      toast.error('Failed to update GPS location');
    }
  };

  return (
    <div className="space-y-6">
      <div>
        <h2 className="text-3xl mb-2 text-white">GPS Tracking</h2>
      </div>

      {loading ? (
        <div className="text-center py-12 text-muted-foreground">
          Loading tracking data...
        </div>
      ) : livestock.length === 0 ? (
        <Card>
          <CardContent className="py-12 text-center">
            <MapPin className="size-12 mx-auto mb-4 text-muted-foreground" />
            <p className="text-muted-foreground">
              No GPS-enabled livestock found. Add location data to your animals to enable tracking.
            </p>
          </CardContent>
        </Card>
      ) : (
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* Animal List */}
          <Card className="lg:col-span-1">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Navigation className="size-5" />
                Tracked Animals
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-2">
                {livestock.map((animal) => (
                  <button
                    key={animal.id}
                    onClick={() => setSelectedAnimal(animal)}
                    className={`w-full text-left p-3 rounded-lg border transition-all ${
                      selectedAnimal?.id === animal.id
                        ? 'bg-green-50 border-green-300'
                        : 'hover:bg-gray-50 border-gray-200'
                    }`}
                  >
                    <div className="flex items-start justify-between mb-1">
                      <div>
                        <p className="font-medium">{animal.breed}</p>
                        <p className="text-sm text-muted-foreground font-mono">
                          {animal.rfidTag}
                        </p>
                      </div>
                      <Badge variant={animal.healthStatus === 'healthy' ? 'default' : 'destructive'}>
                        {animal.healthStatus}
                      </Badge>
                    </div>
                    <div className="flex items-center gap-1 text-sm text-muted-foreground mt-2">
                      <MapPin className="size-3" />
                      {animal.location?.name || 'Unknown location'}
                    </div>
                  </button>
                ))}
              </div>
            </CardContent>
          </Card>

          {/* Map and Details */}
          <div className="lg:col-span-2 space-y-6">
            {/* Map Placeholder */}
            <Card>
              <CardHeader className="flex flex-row items-center justify-between">
                <CardTitle>Live Location Map</CardTitle>
                <Button onClick={simulateGPSUpdate} size="sm">
                  <RefreshCw className="size-4 mr-2" />
                  Simulate GPS Update
                </Button>
              </CardHeader>
              <CardContent>
                {selectedAnimal ? (
                  <div className="relative bg-gradient-to-br from-green-100 to-blue-100 rounded-lg p-8 h-[400px] flex items-center justify-center">
                    {/* Simple map visualization */}
                    <div className="text-center">
                      <div className="relative inline-block">
                        <div className="absolute inset-0 animate-ping">
                          <MapPin className="size-16 text-green-500 opacity-75" />
                        </div>
                        <MapPin className="size-16 text-green-600 relative z-10" />
                      </div>
                      <div className="mt-6 bg-white/90 backdrop-blur p-4 rounded-lg max-w-sm mx-auto">
                        <h4 className="font-medium mb-2">{selectedAnimal.breed}</h4>
                        <p className="text-sm text-muted-foreground font-mono mb-2">
                          {selectedAnimal.rfidTag}
                        </p>
                        <div className="space-y-1 text-sm">
                          <p>
                            <span className="font-medium">Location:</span>{' '}
                            {selectedAnimal.location?.name || 'Unknown'}
                          </p>
                          <p>
                            <span className="font-medium">Coordinates:</span>{' '}
                            {selectedAnimal.location?.lat.toFixed(6)},{' '}
                            {selectedAnimal.location?.lng.toFixed(6)}
                          </p>
                          {selectedAnimal.lastSeen && (
                            <p>
                              <span className="font-medium">Last Seen:</span>{' '}
                              {new Date(selectedAnimal.lastSeen).toLocaleString()}
                            </p>
                          )}
                        </div>
                      </div>
                      <div className="mt-4 text-xs text-muted-foreground">
                        <p>In production, this would show an interactive map</p>
                        <p>with real GPS coordinates from RFID readers</p>
                      </div>
                    </div>
                  </div>
                ) : (
                  <div className="h-[400px] flex items-center justify-center text-muted-foreground">
                    Select an animal to view location
                  </div>
                )}
              </CardContent>
            </Card>

            {/* Movement History */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <History className="size-5" />
                  Movement History
                </CardTitle>
              </CardHeader>
              <CardContent>
                {loadingMovements ? (
                  <div className="text-center py-8 text-muted-foreground">
                    Loading movement history...
                  </div>
                ) : movements.length === 0 ? (
                  <div className="text-center py-8 text-muted-foreground">
                    No movement history available for this animal
                  </div>
                ) : (
                  <div className="space-y-2 max-h-[300px] overflow-y-auto">
                    {movements.map((movement) => (
                      <div
                        key={movement.id}
                        className="p-3 rounded-lg border bg-gray-50 flex items-start justify-between"
                      >
                        <div className="flex items-start gap-3">
                          <MapPin className="size-4 mt-1 text-green-600" />
                          <div>
                            <p className="text-sm font-medium">
                              Position Update
                            </p>
                            <p className="text-xs text-muted-foreground">
                              Lat: {movement.latitude.toFixed(6)}, Lng: {movement.longitude.toFixed(6)}
                            </p>
                          </div>
                        </div>
                        <p className="text-xs text-muted-foreground">
                          {new Date(movement.timestamp).toLocaleString()}
                        </p>
                      </div>
                    ))}
                  </div>
                )}
              </CardContent>
            </Card>
          </div>
        </div>
      )}
    </div>
  );
}