import { useState } from 'react';
import { Button } from './ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from './ui/card';
import { Database, Loader2 } from 'lucide-react';
import { projectId } from '../utils/supabase/info';
import { toast } from 'sonner';

interface SampleDataLoaderProps {
  accessToken: string;
  onDataLoaded: () => void;
}

export function SampleDataLoader({ accessToken, onDataLoaded }: SampleDataLoaderProps) {
  const [loading, setLoading] = useState(false);

  const sampleLivestock = [
    { rfidTag: 'RFID-001234', breed: 'Holstein', age: 24, healthStatus: 'healthy', weight: 650, gender: 'female', locationName: 'North Pasture' },
    { rfidTag: 'RFID-001235', breed: 'Angus', age: 18, healthStatus: 'healthy', weight: 580, gender: 'male', locationName: 'South Field' },
    { rfidTag: 'RFID-001236', breed: 'Jersey', age: 30, healthStatus: 'healthy', weight: 420, gender: 'female', locationName: 'East Meadow' },
    { rfidTag: 'RFID-001237', breed: 'Hereford', age: 22, healthStatus: 'sick', weight: 590, gender: 'female', locationName: 'West Paddock' },
    { rfidTag: 'RFID-001238', breed: 'Holstein', age: 28, healthStatus: 'healthy', weight: 670, gender: 'female', locationName: 'North Pasture' },
    { rfidTag: 'RFID-001239', breed: 'Angus', age: 20, healthStatus: 'treatment', weight: 600, gender: 'male', locationName: 'Barn Area' },
    { rfidTag: 'RFID-001240', breed: 'Charolais', age: 26, healthStatus: 'healthy', weight: 720, gender: 'male', locationName: 'South Field' },
    { rfidTag: 'RFID-001241', breed: 'Limousin', age: 19, healthStatus: 'healthy', weight: 610, gender: 'female', locationName: 'East Meadow' },
    { rfidTag: 'RFID-001242', breed: 'Simmental', age: 32, healthStatus: 'healthy', weight: 690, gender: 'female', locationName: 'North Pasture' },
    { rfidTag: 'RFID-001243', breed: 'Holstein', age: 21, healthStatus: 'healthy', weight: 640, gender: 'female', locationName: 'West Paddock' },
    { rfidTag: 'RFID-001244', breed: 'Angus', age: 25, healthStatus: 'healthy', weight: 595, gender: 'male', locationName: 'South Field' },
    { rfidTag: 'RFID-001245', breed: 'Jersey', age: 27, healthStatus: 'healthy', weight: 430, gender: 'female', locationName: 'East Meadow' },
  ];

  const sampleAlerts = [
    { 
      type: 'boundary_breach', 
      severity: 'high', 
      message: 'Animal RFID-001237 has wandered outside designated area',
      status: 'active'
    },
    { 
      type: 'health_warning', 
      severity: 'medium', 
      message: 'Animal RFID-001239 requires veterinary check',
      status: 'active'
    },
    { 
      type: 'movement_alert', 
      severity: 'low', 
      message: 'Unusual movement pattern detected for RFID-001241',
      status: 'resolved'
    },
  ];

  const loadSampleData = async () => {
    setLoading(true);
    
    try {
      // Add livestock
      let successCount = 0;
      for (const animal of sampleLivestock) {
        const response = await fetch(
          `https://${projectId}.supabase.co/functions/v1/make-server-ebf166d3/livestock`,
          {
            method: 'POST',
            headers: {
              'Content-Type': 'application/json',
              'Authorization': `Bearer ${accessToken}`
            },
            body: JSON.stringify({
              ...animal,
              location: {
                name: animal.locationName,
                lat: 29.7604 + (Math.random() - 0.5) * 0.1, // Random coords around Houston, TX
                lng: -95.3698 + (Math.random() - 0.5) * 0.1
              },
              lastSeen: new Date().toISOString()
            })
          }
        );

        if (response.ok) {
          successCount++;
        }
      }

      // Get livestock to associate with alerts
      const livestockRes = await fetch(
        `https://${projectId}.supabase.co/functions/v1/make-server-ebf166d3/livestock`,
        {
          headers: { 'Authorization': `Bearer ${accessToken}` }
        }
      );
      const livestockData = await livestockRes.json();

      // Add alerts
      if (livestockData.livestock && livestockData.livestock.length > 0) {
        for (let i = 0; i < sampleAlerts.length; i++) {
          const alert = sampleAlerts[i];
          const animal = livestockData.livestock[i % livestockData.livestock.length];
          
          await fetch(
            `https://${projectId}.supabase.co/functions/v1/make-server-ebf166d3/alerts`,
            {
              method: 'POST',
              headers: {
                'Content-Type': 'application/json',
                'Authorization': `Bearer ${accessToken}`
              },
              body: JSON.stringify({
                ...alert,
                animalId: animal.id
              })
            }
          );
        }
      }

      // Add some movement history for tracking
      if (livestockData.livestock && livestockData.livestock.length > 0) {
        const animal = livestockData.livestock[0];
        for (let i = 0; i < 5; i++) {
          await fetch(
            `https://${projectId}.supabase.co/functions/v1/make-server-ebf166d3/movements`,
            {
              method: 'POST',
              headers: {
                'Content-Type': 'application/json',
                'Authorization': `Bearer ${accessToken}`
              },
              body: JSON.stringify({
                animalId: animal.id,
                latitude: 29.7604 + (Math.random() - 0.5) * 0.01,
                longitude: -95.3698 + (Math.random() - 0.5) * 0.01
              })
            }
          );
        }
      }

      toast.success(`Successfully loaded ${successCount} animals with sample alerts!`);
      onDataLoaded();
    } catch (error) {
      console.error('Error loading sample data:', error);
      toast.error('Failed to load sample data');
    } finally {
      setLoading(false);
    }
  };

  return (
    <Card className="border-2 border-dashed border-orange-300 bg-gradient-to-br from-orange-50/50 to-amber-50/50">
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <Database className="size-5" />
          Load Sample Data
        </CardTitle>
        <CardDescription>
          Populate your system with sample livestock, alerts, and tracking data to explore features
        </CardDescription>
      </CardHeader>
      <CardContent>
        <Button 
          onClick={loadSampleData} 
          disabled={loading}
          className="w-full"
          size="lg"
        >
          {loading ? (
            <>
              <Loader2 className="size-4 mr-2 animate-spin" />
              Loading Sample Data...
            </>
          ) : (
            <>
              <Database className="size-4 mr-2" />
              Load 12 Sample Animals + Alerts
            </>
          )}
        </Button>
      </CardContent>
    </Card>
  );
}
