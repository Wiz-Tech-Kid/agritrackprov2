import { useState, useEffect } from 'react';
import { AuthPage } from './components/AuthPage';
import { Dashboard } from './components/Dashboard';
import { LivestockManagement } from './components/LivestockManagement';
import { AlertsPanel } from './components/AlertsPanel';
import { MapTracking } from './components/MapTracking';
import { FarmerManagement } from './components/FarmerManagement';
import { Button } from './components/ui/button';
import { Beef, LayoutDashboard, Users, Bell, Map, UserCog, LogOut, Menu, X, ChevronRight } from 'lucide-react';
import { Toaster } from './components/ui/sonner';
import { supabase } from './utils/supabase/client';
import { projectId } from './utils/supabase/info';
import { motion, AnimatePresence } from 'motion/react';
import logo from 'figma:asset/965825fdc40d664031bd763ecb360668258e01d7.png';

type View = 'dashboard' | 'livestock' | 'alerts' | 'map' | 'farmers';

export default function App() {
  const [accessToken, setAccessToken] = useState<string | null>(null);
  const [currentView, setCurrentView] = useState<View>('dashboard');
  const [user, setUser] = useState<any>(null);
  const [sidebarOpen, setSidebarOpen] = useState(true);
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  useEffect(() => {
    checkSession();
  }, []);

  useEffect(() => {
    if (accessToken) {
      fetchUserData();
    }
  }, [accessToken]);

  const checkSession = async () => {
    const { data } = await supabase.auth.getSession();
    if (data.session?.access_token) {
      setAccessToken(data.session.access_token);
    }
  };

  const fetchUserData = async () => {
    if (!accessToken) return;

    try {
      const response = await fetch(
        `https://${projectId}.supabase.co/functions/v1/make-server-ebf166d3/user`,
        {
          headers: { 'Authorization': `Bearer ${accessToken}` }
        }
      );

      const data = await response.json();
      if (response.ok) {
        setUser(data.user);
      }
    } catch (error) {
      console.error('Error fetching user data:', error);
    }
  };

  const handleAuthSuccess = (token: string) => {
    setAccessToken(token);
  };

  const handleLogout = async () => {
    await supabase.auth.signOut();
    setAccessToken(null);
    setUser(null);
    setCurrentView('dashboard');
  };

  const navItems = [
    { id: 'dashboard' as View, label: 'Dashboard', icon: LayoutDashboard },
    { id: 'livestock' as View, label: 'Livestock', icon: Beef },
    { id: 'alerts' as View, label: 'Alerts', icon: Bell },
    { id: 'map' as View, label: 'GPS Tracking', icon: Map },
  ];

  if (user?.role === 'admin') {
    navItems.push({ id: 'farmers' as View, label: 'Farmers', icon: UserCog });
  }

  if (!accessToken) {
    return <AuthPage onAuthSuccess={handleAuthSuccess} />;
  }

  return (
    <div className="min-h-screen relative overflow-hidden">
      {/* Agriculture Background */}
      <div className="fixed inset-0 z-0">
        <div className="absolute inset-0 bg-gradient-to-br from-green-900/95 via-emerald-800/95 to-green-900/95" />
        <img 
          src="https://images.unsplash.com/photo-1681585223949-dab44b4441bc?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxncmVlbiUyMGFncmljdWx0dXJlJTIwZmllbGR8ZW58MXx8fHwxNzYyNTk0NzAzfDA&ixlib=rb-4.1.0&q=80&w=1080" 
          alt="Agriculture background"
          className="w-full h-full object-cover opacity-20"
        />
        <div className="absolute inset-0 bg-gradient-to-t from-black/50 via-transparent to-black/30" />
      </div>

      <Toaster />
      
      <div className="relative z-10 flex h-screen">
        {/* Sidebar - Desktop */}
        <motion.aside
          initial={{ x: -300 }}
          animate={{ x: sidebarOpen ? 0 : -280 }}
          transition={{ type: "spring", stiffness: 300, damping: 30 }}
          className="hidden lg:flex flex-col w-72 bg-white/10 backdrop-blur-xl border-r border-white/20 shadow-2xl"
        >
          {/* Logo */}
          <div className="p-6 border-b border-white/20">
            <motion.div 
              className="flex flex-col items-center justify-center"
              whileHover={{ scale: 1.02 }}
              transition={{ type: "spring", stiffness: 400 }}
            >
              <motion.img
                src={logo}
                alt="AgriTrack Logo"
                className="w-32 h-32 object-contain mb-2"
                whileHover={{ rotate: 360 }}
                transition={{ duration: 0.6 }}
              />
              <div className="text-center">
                <h1 className="text-xl text-white">AgriTrack Pro</h1>
                <p className="text-xs text-green-200">Livestock Management</p>
              </div>
            </motion.div>
          </div>

          {/* Navigation */}
          <nav className="flex-1 p-4 space-y-2">
            {navItems.map((item, index) => {
              const Icon = item.icon;
              const isActive = currentView === item.id;
              return (
                <motion.div
                  key={item.id}
                  initial={{ opacity: 0, x: -20 }}
                  animate={{ opacity: 1, x: 0 }}
                  transition={{ delay: index * 0.1 }}
                >
                  <motion.button
                    onClick={() => setCurrentView(item.id)}
                    className={`w-full flex items-center gap-3 px-4 py-3 rounded-xl transition-all ${
                      isActive 
                        ? 'bg-white text-green-700 shadow-lg' 
                        : 'text-white hover:bg-white/10'
                    }`}
                    whileHover={{ x: 5, scale: 1.02 }}
                    whileTap={{ scale: 0.98 }}
                  >
                    <motion.div
                      animate={isActive ? { rotate: 360 } : {}}
                      transition={{ duration: 0.5 }}
                    >
                      <Icon className="size-5" />
                    </motion.div>
                    <span className="font-medium">{item.label}</span>
                    {isActive && (
                      <motion.div
                        layoutId="activeIndicator"
                        className="ml-auto"
                      >
                        <ChevronRight className="size-4" />
                      </motion.div>
                    )}
                  </motion.button>
                </motion.div>
              );
            })}
          </nav>

          {/* User Info */}
          <div className="p-4 border-t border-white/20">
            <div className="bg-white/10 backdrop-blur rounded-xl p-4 mb-3">
              <p className="text-white font-medium">{user?.name || 'User'}</p>
              <p className="text-green-200 text-sm capitalize">{user?.role || 'farmer'}</p>
              <p className="text-green-300 text-xs mt-1">{user?.farmLocation || 'Location not set'}</p>
            </div>
            <Button 
              onClick={handleLogout}
              variant="outline"
              className="w-full bg-white/10 border-white/20 text-white hover:bg-white/20"
            >
              <LogOut className="size-4 mr-2" />
              Logout
            </Button>
          </div>
        </motion.aside>

        {/* Main Content Area */}
        <div className="flex-1 flex flex-col overflow-hidden">
          {/* Mobile Header */}
          <motion.header 
            initial={{ y: -100 }}
            animate={{ y: 0 }}
            className="lg:hidden bg-white/10 backdrop-blur-xl border-b border-white/20 shadow-lg"
          >
            <div className="px-4 py-4 flex items-center justify-between">
              <div className="flex items-center gap-3">
                <img src={logo} alt="Logo" className="w-10 h-10 object-contain" />
                <div>
                  <h1 className="text-lg text-white">AgriTrack Pro</h1>
                  <p className="text-xs text-green-200">Livestock Management</p>
                </div>
              </div>
              <div className="flex items-center gap-2">
                <Button
                  variant="ghost"
                  size="sm"
                  onClick={handleLogout}
                  className="text-white hover:bg-white/20"
                >
                  <LogOut className="size-5" />
                </Button>
                <Button
                  variant="ghost"
                  size="sm"
                  onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
                  className="text-white hover:bg-white/20"
                >
                  {mobileMenuOpen ? <X className="size-6" /> : <Menu className="size-6" />}
                </Button>
              </div>
            </div>

            {/* Mobile Menu */}
            <AnimatePresence>
              {mobileMenuOpen && (
                <motion.nav
                  initial={{ height: 0, opacity: 0 }}
                  animate={{ height: 'auto', opacity: 1 }}
                  exit={{ height: 0, opacity: 0 }}
                  className="overflow-hidden border-t border-white/20"
                >
                  <div className="p-4 space-y-2">
                    {navItems.map((item) => {
                      const Icon = item.icon;
                      const isActive = currentView === item.id;
                      return (
                        <button
                          key={item.id}
                          onClick={() => {
                            setCurrentView(item.id);
                            setMobileMenuOpen(false);
                          }}
                          className={`w-full flex items-center gap-3 px-4 py-3 rounded-xl ${
                            isActive 
                              ? 'bg-white text-green-700' 
                              : 'text-white hover:bg-white/10'
                          }`}
                        >
                          <Icon className="size-5" />
                          <span>{item.label}</span>
                        </button>
                      );
                    })}
                  </div>
                </motion.nav>
              )}
            </AnimatePresence>
          </motion.header>

          {/* Page Content */}
          <main className="flex-1 overflow-y-auto p-4 lg:p-8">
            <AnimatePresence mode="wait">
              <motion.div
                key={currentView}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -20 }}
                transition={{ duration: 0.3 }}
              >
                {currentView === 'dashboard' && <Dashboard accessToken={accessToken} userRole={user?.role || 'farmer'} />}
                {currentView === 'livestock' && <LivestockManagement accessToken={accessToken} />}
                {currentView === 'alerts' && <AlertsPanel accessToken={accessToken} />}
                {currentView === 'map' && <MapTracking accessToken={accessToken} />}
                {currentView === 'farmers' && user?.role === 'admin' && <FarmerManagement accessToken={accessToken} />}
              </motion.div>
            </AnimatePresence>
          </main>
        </div>
      </div>
    </div>
  );
}